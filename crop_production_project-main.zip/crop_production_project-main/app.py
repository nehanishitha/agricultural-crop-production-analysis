
import os
import mysql.connector
from flask import Flask, render_template, request, redirect, url_for
from analysis import get_data, create_graph

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static")
)


def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="aimlb5",
        database="crop_db"
    )


# 1. HOME PAGE
@app.route("/")
def home():
    selected_crop = request.args.get("crop_id", "")
    crop_id = int(selected_crop) if selected_crop.isdigit() else None

    df = get_data(crop_id)
    create_graph(crop_id)

    if not df:
        total_production = 0
        average_yield = 0
    else:
        total_production = sum(item["production"] for item in df)
        average_yield = sum(item["yield"] for item in df) / len(df)

    con = get_connection()
    cursor = con.cursor()

    if crop_id is not None:
        cursor.execute("""
            SELECT record_id, crop_name, region_name, year,
                   cultivated_area, production, rainfall
            FROM crop_records
            JOIN crops USING (crop_id)
            JOIN regions USING (region_id)
            WHERE crop_records.crop_id = %s
            ORDER BY record_id ASC
        """, (crop_id,))
    else:
        cursor.execute("""
            SELECT record_id, crop_name, region_name, year,
                   cultivated_area, production, rainfall
            FROM crop_records
            JOIN crops USING (crop_id)
            JOIN regions USING (region_id)
            ORDER BY record_id ASC
        """)

    records = cursor.fetchall()

    cursor.execute("""
        SELECT crop_id, crop_name
        FROM crops
        ORDER BY crop_name
    """)
    crops = cursor.fetchall()

    cursor.execute("""
        SELECT region_id, region_name
        FROM regions
        ORDER BY region_name
    """)
    regions = cursor.fetchall()

    cursor.close()
    con.close()

    return render_template(
        "index.html",
        records=records,
        crops=crops,
        regions=regions,
        selected_crop=selected_crop,
        total_production=round(total_production, 2),
        average_yield=round(average_yield, 2)
    )


# 2. ADD CROP PAGE
@app.route("/add", methods=["GET", "POST"])
def add():
    if request.method == "GET":
        con = get_connection()
        cursor = con.cursor()

        cursor.execute(
            "SELECT crop_id, crop_name FROM crops ORDER BY crop_name"
        )
        crops = cursor.fetchall()

        cursor.execute(
            "SELECT region_id, region_name FROM regions ORDER BY region_name"
        )
        regions = cursor.fetchall()

        cursor.close()
        con.close()

        return render_template(
            "add_crop.html",
            crops=crops,
            regions=regions
        )

    try:
        crop_id = int(request.form["crop_id"])
        region_id = int(request.form["region_id"])
        year = int(request.form["year"])
        area = float(request.form["area"])
        production = float(request.form["production"])
        rainfall = float(request.form.get("rainfall") or 0)

        if year < 1900 or year > 2100:
            return "Invalid year.", 400

        if area <= 0:
            return "Cultivated area must be greater than zero.", 400

        if production < 0 or rainfall < 0:
            return "Production and rainfall cannot be negative.", 400

    except (ValueError, TypeError, KeyError):
        return "Please enter valid crop details.", 400

    con = get_connection()
    cursor = con.cursor()

    try:
        cursor.execute("""
            INSERT INTO crop_records
            (crop_id, region_id, year, cultivated_area, production, rainfall)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (
            crop_id, region_id, year, area, production, rainfall
        ))
        con.commit()
    finally:
        cursor.close()
        con.close()

    return redirect(url_for("view_crops"))


# 3. VIEW CROPS PAGE
@app.route("/crops")
def view_crops():
    con = get_connection()
    cursor = con.cursor()

    cursor.execute("""
        SELECT record_id, crop_name, region_name, year,
               cultivated_area, production, rainfall
        FROM crop_records
        JOIN crops USING (crop_id)
        JOIN regions USING (region_id)
        ORDER BY record_id ASC
    """)

    records = cursor.fetchall()
    cursor.close()
    con.close()

    return render_template("crops.html", records=records)

@app.route("/update/<int:record_id>", methods=["GET", "POST"])
def update(record_id):
    con = get_connection()
    cursor = con.cursor()

    if request.method == "POST":
        year = int(request.form["year"])
        area = float(request.form["area"])
        production = float(request.form["production"])
        rainfall = float(request.form.get("rainfall") or 0)

        cursor.execute("""
            UPDATE crop_records
            SET year=%s, cultivated_area=%s, production=%s, rainfall=%s
            WHERE record_id=%s
        """, (year, area, production, rainfall, record_id))

        con.commit()
        cursor.close()
        con.close()
        return redirect(url_for("view_crops"))

    cursor.execute("""
        SELECT record_id, year, cultivated_area, production, rainfall
        FROM crop_records
        WHERE record_id=%s
    """, (record_id,))
    record = cursor.fetchone()

    cursor.close()
    con.close()

    return render_template("update_crop.html", record=record)
# DELETE CROP
@app.route("/delete/<int:record_id>")
def delete(record_id):
    con = get_connection()
    cursor = con.cursor()

    try:
        cursor.execute(
            "DELETE FROM crop_records WHERE record_id = %s",
            (record_id,)
        )
        con.commit()
    finally:
        cursor.close()
        con.close()

    return redirect(url_for("view_crops"))


# 4. ANALYSIS PAGE
@app.route("/analysis")
def analysis_page():
    df = get_data(None)
    create_graph(None)

    if not df:
        total_production = 0
        average_yield = 0
    else:
        total_production = sum(item["production"] for item in df)
        average_yield = sum(item["yield"] for item in df) / len(df)

    return render_template(
        "analysis.html",
        total_production=round(total_production, 2),
        average_yield=round(average_yield, 2)
    )


if __name__ == "__main__":
    app.run(debug=True)
