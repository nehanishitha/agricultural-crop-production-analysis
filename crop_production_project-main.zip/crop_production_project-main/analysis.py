
import os
import mysql.connector
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from flask import current_app


def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="aimlb5",
        database="crop_db"
    )


def get_data(crop_id=None):
    con = get_connection()
    cursor = con.cursor()

    query = """
        SELECT production, cultivated_area
        FROM crop_records
    """
    params = ()

    if crop_id is not None:
        query += " WHERE crop_id = %s"
        params = (crop_id,)

    cursor.execute(query, params)
    rows = cursor.fetchall()

    cursor.close()
    con.close()

    data = []

    for production, area in rows:
        production = float(production)
        area = float(area)
        yield_value = production / area if area > 0 else 0

        data.append({
            "production": production,
            "yield": yield_value
        })

    return data


def create_graph(crop_id=None):
    con = get_connection()
    cursor = con.cursor()

    query = """
        SELECT year, SUM(production)
        FROM crop_records
    """
    params = ()

    if crop_id is not None:
        query += " WHERE crop_id = %s"
        params = (crop_id,)

    query += " GROUP BY year ORDER BY year"

    cursor.execute(query, params)
    rows = cursor.fetchall()

    cursor.close()
    con.close()

    if not rows:
        plt.close("all")
        return False

    years = [row[0] for row in rows]
    production = [float(row[1]) for row in rows]

    plt.figure(figsize=(8, 4))
    plt.bar(years, production)
    plt.title("Yearly Crop Production")
    plt.xlabel("Year")
    plt.ylabel("Production")
    plt.tight_layout()

    static_folder = current_app.static_folder
    os.makedirs(static_folder, exist_ok=True)

    graph_path = os.path.join(
        static_folder,
        "crop_production.png"
    )

    plt.savefig(graph_path)
    plt.close()

    return True
